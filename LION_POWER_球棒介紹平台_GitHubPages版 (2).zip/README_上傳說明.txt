LION POWER 球棒介紹平台｜上傳說明

1. 將 index.html、robots.txt、sitemap.xml 上傳到 GitHub 專案 lionpower-shop 的最外層。
2. 檔名必須保持 index.html，不要變成 index.html.html。
3. GitHub：Settings → Pages → Deploy from a branch。
4. Branch 選 main，資料夾選 /(root)，按 Save。
5. 網址：
   https://a0958773442-cell.github.io/lionpower-shop/

本版本已包含：
- 手機、平板、電腦響應式版面
- 火焰主視覺
- WBSC 認證區
- 球棒規格介紹
- 訂購規格自動整理與金額計算
- LINE、Email、Google 搜尋連結
- Google 搜尋引擎基本 SEO 標籤
